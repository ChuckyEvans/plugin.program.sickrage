import xbmcplugin
import xbmcgui
import urllib
import re

import resources.lib.util as util

_STATUS_STYLE = {
    'Downloaded': ('[COLOR green]\u2713  Downloaded[/COLOR]', 'downloaded'),
    'Snatched':   ('[COLOR cyan]\u2193  Snatched[/COLOR]',   'snatched'),
    'Failed':     ('[COLOR red]\u2715  Failed[/COLOR]',       'wanted'),
}

def menu():
    history = util.api.getHistory()
    shows   = {}

    for show in history:
        uId = str(show['tvdbid']) + '-' + str(show['season']) + '-' + str(show['episode'])
        if (not uId in shows) or (show['status'] == 'Downloaded'):
            shows[uId] = show

    shows = sorted(shows.values(), key=lambda s: s['date'], reverse=True)

    for show in shows:
        status           = show.get('status', '')
        style, icon_name = _STATUS_STYLE.get(status, (
            '[COLOR gray]' + status + '[/COLOR]', 'wanted'))

        dt_str = util.formatDateTime(show['date'])
        ep_str = util.formatEpisodeName(show)
        label  = style + '  [COLOR gray]' + dt_str + '[/COLOR]  ' + ep_str

        url  = util.getShowURL(show['tvdbid'])
        li   = xbmcgui.ListItem(label=label)
        # Use show poster image if available so the left pane shows the poster
        try:
            poster = util.api.getShowPoster(show.get('tvdbid'))
        except Exception:
            poster = None
        if poster:
            try:
                _poster = util.maybe_cache_image(poster, subdir='poster_cache') or poster
            except Exception:
                _poster = poster
            li.setArt({'icon': _poster, 'thumb': _poster})
            util.set_video_info(li, name=show.get('show_name',''), summary=show.get('overview',''), premiered=show.get('first_aired',''), image=poster)
        else:
            icon = util.getIcon(icon_name)
            try:
                _icon = util.maybe_cache_image(icon, subdir='poster_cache') or icon
            except Exception:
                _icon = icon
            li.setArt({'icon': _icon, 'thumb': _icon})
            util.set_video_info(li, name=show.get('show_name',''), summary=show.get('overview',''), premiered=show.get('first_aired',''), image=icon)
        li.addContextMenuItems([
            ('Refresh list', util.getContextCommand('refresh'))
        ], True)
        xbmcplugin.addDirectoryItem(handle=util.pluginId, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(util.pluginId, cacheToDisc=False)
