import xbmcplugin
import xbmcgui
import urllib

import resources.lib.util as util
import urllib.request as _req
import json as _json
import xml.etree.ElementTree as ET

def menu():
    # Ensure SickRage backend configured before attempting provider calls
    sr_url = (util.plugin.getSetting('url') or '').strip()
    sr_key = (util.plugin.getSetting('key') or '').strip()
    if not sr_url or not sr_key:
        util.message('SickRage', 'SickRage not configured', 'Set URL and API key in Add-on settings')
        indexers = []
    else:
        try:
            # Use legacy API for indexers; avoid REST/provider changes for stability
            indexers = util.api.getIndexers()
        except Exception as e:
            util.message('Error', 'Cannot fetch providers', str(e))
            indexers = []

    # Add Scan / Refresh action
    scan_url = util.getActionURL('providersScan')
    li = xbmcgui.ListItem(label='Scan/Refresh Providers')
    li.setArt({'icon': util.getIcon('settings'), 'thumb': util.getIcon('settings')})
    xbmcplugin.addDirectoryItem(handle=util.pluginId, url=scan_url, listitem=li, isFolder=False)

    # Show quick Jackett link only (do not perform embedded Jackett indexer calls)
    jackett_url, jackett_key = util.get_jackett()
    # normalize values
    jackett_url = (jackett_url or '').strip()
    jackett_key = (jackett_key or '').strip()
    if jackett_url:
        jlabel = 'Jackett: ' + (jackett_url if len(jackett_url) < 60 else jackett_url[:57] + '...')
        jli = xbmcgui.ListItem(label=jlabel)
        jli.setArt({'icon': util.getIcon('settings'), 'thumb': util.getIcon('settings')})
        xbmcplugin.addDirectoryItem(handle=util.pluginId, url=jackett_url, listitem=jli, isFolder=False)

    # No provider toggle handling here to avoid unstable REST calls

    if not indexers:
        empty = xbmcgui.ListItem(label='No providers found')
        xbmcplugin.addDirectoryItem(handle=util.pluginId, url=util.pluginURL, listitem=empty, isFolder=False)
    else:
        for idx in indexers:
            name = idx.get('name') or idx.get('provider') or 'Unknown'
            enabled = idx.get('enabled', True)
            account = idx.get('requires_auth', False)
            provider_id = idx.get('id') or name
            label = name + (' [enabled]' if enabled else ' [disabled]')
            if account:
                label += ' (requires account)'
            li = xbmcgui.ListItem(label=label)
            # link to detail view for this provider
            params = {'provider': provider_id}
            url = util.pluginURL + '?' + urllib.parse.urlencode({'vf': 'providersDetail', 'provider': provider_id})
            xbmcplugin.addDirectoryItem(handle=util.pluginId, url=url, listitem=li, isFolder=True)

            # Add quick enable/disable actions when supported
            try:
                    # Avoid REST provider status checks; only show details view
                    pass
            except Exception:
                # ignore REST failures
                pass

    xbmcplugin.endOfDirectory(util.pluginId, cacheToDisc=False)


def jackettList():
    # show stored jackett indexers written earlier
    idxs = util.read_addon_data('jackett_indexers.json', [])
    # check auto-rescan interval
    jackett_url, jackett_key = util.get_jackett()
    jackett_url = (jackett_url or '').strip()
    jackett_key = (jackett_key or '').strip()
    try:
        interval = int(util.plugin.getSetting('jackett_rescan_interval') or 0)
    except Exception:
        interval = 0
    last = util.read_addon_data('jackett_last_rescan', 0) or 0
    import time
    now = int(time.time())
    if jackett_url and interval > 0 and (now - int(last)) >= (interval * 60):
        # perform best-effort rescan: call aggregated refresh endpoint
        try:
            if not jackett_key:
                # nothing to do without an API key
                raise ValueError('Jackett API key not configured')
            base = jackett_url.split('/api/v2.0')[0] + '/api/v2.0'
            refresh_url = base + '/indexers/refresh?apikey=' + urllib.parse.quote(jackett_key or '')
            try:
                _req.urlopen(refresh_url, timeout=10)
                util.write_addon_data('jackett_last_rescan', now)
                # re-fetch indexer list using multiple possible endpoints/formats
                entries = _fetch_indexers_from_jackett(base, jackett_key)
                if entries:
                    entries.sort(key=lambda e: ((0 if e['enabled'] else 1), e['title'].lower()))
                    util.write_addon_data('jackett_indexers.json', entries)
                    idxs = entries
            except Exception:
                pass
        except Exception:
            pass
    if not idxs:
        li = xbmcgui.ListItem(label='No Jackett indexers found or Jackett not configured')
        xbmcplugin.addDirectoryItem(handle=util.pluginId, url=util.pluginURL, listitem=li, isFolder=False)
    else:
        # Add a Force Rescan action at top
        rescan_url = util.getActionURL('jackettRescan')
        rescan_li = xbmcgui.ListItem(label='Force Jackett Rescan Now')
        rescan_li.setArt({'icon': util.getIcon('settings'), 'thumb': util.getIcon('settings')})
        xbmcplugin.addDirectoryItem(handle=util.pluginId, url=rescan_url, listitem=rescan_li, isFolder=False)
        
        for idx in idxs:
            label = idx.get('title') + (' [enabled]' if idx.get('enabled') else ' [disabled]')
            li = xbmcgui.ListItem(label=label)
            # open Jackett indexer page
            jackett_url, jackett_key = util.get_jackett()
            if jackett_url:
                # build indexer UI URL
                url = jackett_url.split('/api/v2.0')[0] + '/ui/indexers/' + urllib.parse.quote(idx.get('id'))
            else:
                url = util.pluginURL
            xbmcplugin.addDirectoryItem(handle=util.pluginId, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(util.pluginId, cacheToDisc=False)


def jackettRescan():
    # manual rescan handler: call Jackett refresh endpoint and update stored indexers
    jackett_url, jackett_key = util.get_jackett()
    jackett_url = (jackett_url or '').strip()
    jackett_key = (jackett_key or '').strip()
    if not jackett_url or not jackett_key:
        util.message('Jackett', 'Jackett not configured', 'Set Jackett URL and API key in settings')
        return
    try:
        base = jackett_url.split('/api/v2.0')[0] + '/api/v2.0'
        refresh_url = base + '/indexers/refresh?apikey=' + urllib.parse.quote(jackett_key or '')
        _req.urlopen(refresh_url, timeout=30)
        # fetch and store indexers, trying JSON and Torznab/API endpoints
        entries = _fetch_indexers_from_jackett(base, jackett_key, timeout=30)
        if entries:
            entries.sort(key=lambda e: ((0 if e['enabled'] else 1), e['title'].lower()))
            util.write_addon_data('jackett_indexers.json', entries)
            util.write_addon_data('jackett_last_rescan', int(__import__('time').time()))
            util.message('Jackett', 'Rescan complete', f'{len(entries)} indexers updated')
        else:
            util.message('Jackett', 'Rescan complete', 'No indexers returned')
    except Exception as e:
        util.message('Jackett', 'Rescan failed', str(e))
    # show updated list
    jackettList()


def _fetch_indexers_from_jackett(base_api, apikey, timeout=10):
    """Attempt multiple Jackett endpoints to enumerate indexers.
    Returns list of {'title','enabled','id'} or empty list.
    """
    try_endpoints = []
    # JSON-capable endpoint (jackett exposes /indexers returning JSON in many builds)
    try_endpoints.append((base_api + '/indexers?apikey=' + urllib.parse.quote(apikey), 'json'))
    # Torznab API that can return indexer info via t=indexers
    try_endpoints.append((base_api + '/indexers/all/results/torznab/api?apikey=' + urllib.parse.quote(apikey) + '&t=indexers', 'torznab'))
    # Another possible endpoint
    try_endpoints.append((base_api + '/indexers?apikey=' + urllib.parse.quote(apikey) + '&configured=true', 'json'))

    for url, mode in try_endpoints:
        try:
            resp = _req.urlopen(url, timeout=timeout).read()
            if mode == 'json':
                try:
                    parsed = _json.loads(resp.decode('utf-8'))
                    entries = []
                    if isinstance(parsed, dict):
                        for k, v in parsed.items():
                            title = v.get('title') or v.get('name') or k
                            enabled = bool(v.get('enabled') or v.get('configured'))
                            entries.append({'title': title, 'enabled': enabled, 'id': k})
                    elif isinstance(parsed, list):
                        for v in parsed:
                            title = v.get('title') or v.get('name') or v.get('id')
                            enabled = bool(v.get('enabled', True) or v.get('configured', False))
                            idx_id = v.get('id') or v.get('name') or title
                            entries.append({'title': title, 'enabled': enabled, 'id': idx_id})
                    if entries:
                        return entries
                except Exception:
                    continue
            elif mode == 'torznab':
                # Torznab API returns XML; parse for <channel><item> entries
                try:
                    text = resp.decode('utf-8')
                    root = ET.fromstring(text)
                    # find items
                    items = root.findall('.//item')
                    entries = []
                    for it in items:
                        title = it.findtext('title') or ''
                        # id may be in <guid> or link; use guid text
                        gid = it.findtext('guid') or (it.findtext('link') or title)
                        # enabled/configured flag not exposed via torznab items; assume enabled
                        entries.append({'title': title, 'enabled': True, 'id': gid})
                    if entries:
                        return entries
                except Exception:
                    continue
        except Exception:
            continue
    return []
