import xbmcplugin
import xbmcgui
import urllib

import resources.lib.util as util

# Colour + symbol per episode status
_STATUS_STYLE = {
    'Downloaded': '[COLOR green]\u2713[/COLOR]',
    'Snatched':   '[COLOR cyan]\u2193[/COLOR]',
    'Wanted':     '[COLOR orange]\u25cf[/COLOR]',
    'Skipped':    '[COLOR gray]\u2014[/COLOR]',
    'Ignored':    '[COLOR gray]\u00d7[/COLOR]',
    'Archived':   '[COLOR gold]\u2606[/COLOR]',
    'Failed':     '[COLOR red]\u2715[/COLOR]',
    'Unaired':    '[COLOR gray]\u25a1[/COLOR]',
}

def menu():
    showId     = util.pluginArgs['id']
    season     = int(util.pluginArgs['season'])
    episodes   = util.api.getSeasons(showId, {'season': season})
    poster     = util.api.getShowPoster(showId)

    # Header: show/season metadata with poster on the left
    try:
        show_meta = util.api.getShow(showId)
    except Exception:
        show_meta = {}
    title = show_meta.get('show_name') or ''
    summary = show_meta.get('overview') or ''
    network = show_meta.get('network') or ''
    status = show_meta.get('status') or ''
    premiered = show_meta.get('first_aired') or ''
    genres = show_meta.get('genre') or []

    header_label = '[B]%s — Season %d[/B]' % (title or 'Show', season)
    lih = xbmcgui.ListItem(label=header_label)
    try:
        if poster:
            lih.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
    except Exception:
        pass
    util.set_video_info(lih, name=title, summary=summary, premiered=premiered, network=network, status=status, genres=genres, image=poster)
    xbmcplugin.addDirectoryItem(handle=util.pluginId, url=None, listitem=lih, isFolder=True)

    for epNum in sorted(episodes.keys(), key=int, reverse=True):
        ep     = episodes[epNum]
        status = ep.get('status', '')
        sym    = _STATUS_STYLE.get(status, '[COLOR gray]?[/COLOR]')
        label  = '%s  %s  [COLOR gray]%s[/COLOR]  %s' % (
            sym,
            ('%02d' % int(epNum)),
            status,
            ep.get('name', ''),
        )

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': poster, 'thumb': poster})
        # populate metadata for episode
        ep_name = ep.get('name', '')
        util.set_video_info(li, name=ep_name or label, summary=ep.get('overview',''), premiered=ep.get('first_aired',''), image=poster)
        # If episode is downloaded, make it playable and add play action
        ctx_items = [
            ('Set Episode Status', util.getContextCommand('episodeStatus',
                [showId, season, epNum, status])),
            ('Set Season Status',  util.getContextCommand('seasonStatus',
                [showId, season])),
            ('Manual Search',      util.getContextCommand('episodeSearch',
                [showId, season, epNum])),
            ('Refresh list',       util.getContextCommand('refresh')),
        ]
        # play action when downloaded
        play_url = ''
        if status.lower() == 'downloaded' or status == 'Downloaded':
            # attempt to mark playable and add play option
            li.setProperty('IsPlayable', 'true')
            # append visual indicator to label
            try:
                li.setLabel(label + '  [COLOR green]▶[/COLOR]')
            except Exception:
                pass
            play_url = util.getActionURL('playEpisode', {'id': showId, 'season': season, 'episode': epNum})
            ctx_items.insert(0, ('Play Episode', 'RunPlugin(%s)' % play_url))

        li.addContextMenuItems(ctx_items, True)
        # if play_url is set, make directory item trigger the play action
        item_url = play_url if play_url else None
        xbmcplugin.addDirectoryItem(handle=util.pluginId, url=item_url,
                                    listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(util.pluginId)

